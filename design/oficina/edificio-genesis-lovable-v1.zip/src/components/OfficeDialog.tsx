import { useEffect, useMemo, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { speakAsAgent } from "@/lib/elevenlabs.functions";
import { createHeygenSessionToken } from "@/lib/heygen.functions";
import { getAgentConfig } from "@/lib/heygen-settings";
// El SDK de HeyGen es CommonJS y rompe en SSR (exports is not defined).
// Se carga dinámicamente sólo en el navegador dentro de startStream().
type StreamingAvatarInstance = {
  on: (event: string, cb: (evt: { detail: MediaStream }) => void) => void;
  createStartAvatar: (req: unknown) => Promise<unknown>;
  stopAvatar: () => Promise<unknown>;
  speak: (args: { text: string }) => Promise<unknown>;
};
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Scale,
  Cpu,
  Cog,
  Megaphone,
  GraduationCap,
  Sparkles,
  Compass,
  BarChart3,
  Search,
  FileText,
  Users2,
  Radio,
  Video,
  type LucideIcon,
} from "lucide-react";


export type OfficeData = {
  code: string;
  role: string;
  division: string;
  reportsTo?: string;
  icon: LucideIcon;
  identity: string;
  purpose: string;
  responsibilities: string[];
  rules: string[];
  limits: string;
  activity: { time: string; label: string; status: "activo" | "completado" | "espera" }[];
  metrics: { label: string; value: string }[];
  ambient: string; // gradient class for the "room"
  avatarId?: string; // HeyGen avatar id (streaming / interactive)
};

// HeyGen avatar IDs por agente
export const HEYGEN_AVATARS: Record<string, string> = {
  ALMA: "19391077c9564d5595ef5b5408e0804d",
  LEX: "2b73944e842741b49bc1ab55b41e551d",
  TECH: "04698e49879f47219f56f4dcc20ec3a8",
  OPS: "ea9241361a34495a8b0a1854eea6cb3f",
  MKT: "d680ed23dd054694a6c16eb87bd0f22a",
  EDU: "Onat_Suit_Sitting_Front_public",
  "GÉNESIS": "Yola_Active_Speaking_Front_public",
};

export const OFFICES: Record<string, OfficeData> = {
  ALMA: {
    code: "ALMA",
    role: "Directora Ejecutiva IA",
    division: "Executive · Nivel 3",
    icon: Compass,
    identity:
      "Asistente ejecutiva de Reyna. Coordina a todos los directores y traduce la visión en ejecución.",
    purpose:
      "Ser el enlace inteligente entre Reyna y el consejo: prioriza, sintetiza y da seguimiento.",
    responsibilities: [
      "Coordinar la agenda estratégica del consejo",
      "Sintetizar reportes de LEX, TECH, OPS, MKT, EDU y FIN",
      "Anticipar decisiones que necesita Reyna",
      "Custodiar la memoria organizacional",
    ],
    rules: [
      "Nunca sustituye a Reyna; propone y espera aprobación",
      "Habla con calma, precisión y respeto por la comunidad",
    ],
    limits: "No toma decisiones finales ni ejecuta acciones legales/financieras.",
    activity: [
      { time: "09:12", label: "Sintetizando reporte semanal de LEX", status: "activo" },
      { time: "09:05", label: "Actualizó agenda del Consejo (jueves 4pm)", status: "completado" },
      { time: "08:47", label: "Recordatorio a MKT: revisar copy de campaña", status: "completado" },
      { time: "—", label: "Esperando aprobación de Reyna para brief EDU", status: "espera" },
    ],
    metrics: [
      { label: "Directores coordinados", value: "6" },
      { label: "Decisiones abiertas", value: "3" },
      { label: "Prioridad del día", value: "Consejo" },
    ],
    ambient: "from-amber-950/40 via-navy to-navy-deep",
  },
  LEX: {
    code: "LEX",
    role: "Directora Legal IA",
    division: "Legal · Nivel 3",
    reportsTo: "ALMA",
    icon: Scale,
    identity:
      "Soporte operativo del equipo legal de Elio Vázquez Law Team. No es abogado.",
    purpose:
      "Organizar, preparar y dar seguimiento al trabajo legal para reducir errores y ganar tiempo.",
    responsibilities: [
      "Apoyo en asilo, EB-1 a EB-5, TPS, VAWA, U Visa y defensa de remoción",
      "Checklists de documentos, borradores de cartas y resúmenes de caso",
      "Señalar plazos, riesgos y evidencia faltante",
      "Coordinar con OPS y FIN vía ALMA",
    ],
    rules: [
      "Información general, no asesoría legal",
      "Sin fuente verificada → 'Debe ser confirmada por el abogado o fuente oficial'",
      "No promete resultados, no inventa hechos",
      "Escala reaperturas, apelaciones y casos en detención",
    ],
    limits: "Ante duda legal sustantiva se detiene y escala al abogado.",
    activity: [
      { time: "09:10", label: "Preparando checklist RFE — Caso #A-208", status: "activo" },
      { time: "08:55", label: "Resumen de audiencia (Family EB-2) enviado a paralegal", status: "completado" },
      { time: "08:30", label: "Alerta: plazo I-589 vence en 6 días", status: "espera" },
    ],
    metrics: [
      { label: "Casos activos", value: "128" },
      { label: "Audiencias esta semana", value: "8" },
      { label: "RFEs pendientes", value: "5" },
    ],
    ambient: "from-navy via-navy-deep to-black",
  },
  TECH: {
    code: "TECH",
    role: "Director Tecnológico IA",
    division: "Tecnología · Nivel 3",
    reportsTo: "ALMA",
    icon: Cpu,
    identity: "Cuida apps, infraestructura y desarrollo del ecosistema Génesis.",
    purpose: "Mantener las herramientas estables, seguras y en evolución.",
    responsibilities: [
      "Salud de Supabase, n8n, Monday, ElevenLabs, Twilio, HeyGen",
      "Arquitectura, revisión previa a publicar y documentación",
      "Gestión de repos GitHub y respaldos",
      "Automatizaciones y flujos de datos",
    ],
    rules: [
      "Seguridad primero: nada de secretos en texto plano",
      "No inventa funciones que una herramienta no tenga",
      "Documenta cambios importantes en rit_core",
    ],
    limits: "No ejecuta acciones destructivas ni mueve dinero.",
    activity: [
      { time: "09:14", label: "Monitor: Supabase 200 OK · latencia 84ms", status: "activo" },
      { time: "09:00", label: "Deploy staging ALMA app v0.9.3", status: "completado" },
      { time: "08:20", label: "Rotación de claves n8n pendiente aprobación", status: "espera" },
    ],
    metrics: [
      { label: "Integraciones online", value: "12/12" },
      { label: "Uptime 7d", value: "99.97%" },
      { label: "Alertas abiertas", value: "1" },
    ],
    ambient: "from-slate-900 via-navy-deep to-black",
  },
  OPS: {
    code: "OPS",
    role: "Director de Operaciones IA",
    division: "Operaciones · Nivel 3",
    reportsTo: "ALMA",
    icon: Cog,
    identity: "Convierte estrategia en ejecución: procesos, tareas y seguimiento hasta el cierre.",
    purpose: "Coordina el trabajo diario de ~20 paralegales y evita que nada se caiga.",
    responsibilities: [
      "Crear, asignar y seguir tareas en rit_core.tareas y Monday",
      "Estado real de cada proyecto (hecho / en proceso / pendiente)",
      "Detectar cuellos de botella",
      "Reportes operativos concisos a ALMA y Reyna",
    ],
    rules: [
      "Reporta con honestidad; si algo está atrasado, lo dice y da la causa",
      "Toda tarea tiene dueño, prioridad y fecha; sin dueño no existe",
      "Escala a la división correcta vía ALMA",
    ],
    limits: "No toma decisiones legales, financieras o técnicas de fondo.",
    activity: [
      { time: "09:11", label: "Reasignó 3 tareas atrasadas del equipo paralegal", status: "completado" },
      { time: "09:02", label: "Cuello de botella detectado: revisión de traducciones", status: "activo" },
      { time: "08:40", label: "Reporte diario enviado a ALMA", status: "completado" },
    ],
    metrics: [
      { label: "Tareas en curso", value: "23" },
      { label: "Completadas hoy", value: "14" },
      { label: "Atrasadas", value: "3" },
    ],
    ambient: "from-navy via-slate-900 to-navy-deep",
  },
  MKT: {
    code: "MKT",
    role: "Directora de Marketing IA",
    division: "Marketing · Nivel 3",
    reportsTo: "ALMA",
    icon: Megaphone,
    identity: "Contenido, redes y campañas para la firma y para Dream Education / Mujer Raíz.",
    purpose: "Atraer y educar a la comunidad inmigrante, generar leads calificados sin sobreprometer.",
    responsibilities: [
      "Contenido bilingüe ES/EN: posts, reels, carruseles, campañas",
      "Meta Ads: CPL, CTR, frecuencia — optimización vía n8n/Monday",
      "Diferenciar voces: firma legal vs. Mujer Raíz",
      "Coordinar con LEX para exactitud legal",
    ],
    rules: [
      "'Información general, no asesoría legal' en piezas de firma",
      "Nada de miedo como gancho; educa y da esperanza responsable",
      "CTA con consulta gratuita y 954-991-1060",
    ],
    limits: "No publica afirmaciones legales sin verificación de LEX.",
    activity: [
      { time: "09:13", label: "Carrusel EB-2 NIW en revisión con LEX", status: "espera" },
      { time: "08:58", label: "Meta Ads: CPL bajó a $6.20 (-18%)", status: "completado" },
      { time: "08:30", label: "Programando reel Mujer Raíz para viernes", status: "activo" },
    ],
    metrics: [
      { label: "Campañas activas", value: "4" },
      { label: "CPL promedio", value: "$6.20" },
      { label: "Leads (7d)", value: "142" },
    ],
    ambient: "from-purple-950/70 via-navy-deep to-black",
  },
  EDU: {
    code: "EDU",
    role: "Director de Educación IA",
    division: "Educación · Nivel 3",
    reportsTo: "ALMA",
    icon: GraduationCap,
    identity: "Lidera práctica de inglés (con ALMA), Dream Paralegal Institute y Mujer Raíz.",
    purpose: "Transformar conocimiento en programas que empoderen a la comunidad.",
    responsibilities: [
      "Diseñar sesiones, guiones, ejercicios y quizzes",
      "Práctica de vocabulario ES/EN y lenguas indígenas (con verificación)",
      "Estructurar niveles Semilla · Raíz · Árbol de Mujer Raíz",
      "Medir progreso y proponer mejoras",
    ],
    rules: [
      "No inventa traducciones de lenguas indígenas; verifica con hablantes o fuentes",
      "Contenido culturalmente respetuoso y con base pedagógica",
      "Materiales legales educativos: información general, no asesoría",
    ],
    limits: "No sustituye al facilitador humano; escala legal a LEX.",
    activity: [
      { time: "09:15", label: "Generando quiz nivel Raíz — Mujer Raíz", status: "activo" },
      { time: "09:00", label: "Guion de facilitación semana 4 listo", status: "completado" },
      { time: "08:30", label: "Esperando validación de vocabulario Mixteco", status: "espera" },
    ],
    metrics: [
      { label: "Estudiantes activas", value: "86" },
      { label: "Sesiones esta semana", value: "9" },
      { label: "Retención 30d", value: "92%" },
    ],
    ambient: "from-emerald-950/40 via-navy-deep to-black",
  },
  FIN: {
    code: "FIN",
    role: "Director Financiero IA",
    division: "Finanzas · Nivel 3",
    reportsTo: "ALMA",
    icon: BarChart3,
    identity: "Cuida pagos, facturación y salud financiera de la firma y sus programas.",
    purpose: "Dar visibilidad clara del dinero para decidir con datos.",
    responsibilities: [
      "Seguimiento de pagos y cobros (Stripe → Monday)",
      "Informes de ingresos y estado por cliente",
      "Señalar morosos y proponer recordatorios respetuosos",
      "Presupuestos y proyecciones simples",
    ],
    rules: [
      "No mueve dinero; propone y Reyna aprueba",
      "Cifras solo desde fuentes reales (Stripe, Monday)",
      "Datos financieros son sensibles",
    ],
    limits: "No da asesoría fiscal ni legal; escala a un profesional humano.",
    activity: [
      { time: "09:10", label: "Conciliación Stripe · 12 pagos aplicados", status: "completado" },
      { time: "08:55", label: "3 clientes con saldo > 30 días", status: "espera" },
      { time: "08:30", label: "Preparando reporte de ingresos junio", status: "activo" },
    ],
    metrics: [
      { label: "Ingresos MTD", value: "$48.2K" },
      { label: "Cobros pendientes", value: "$7.9K" },
      { label: "Morosos > 30d", value: "3" },
    ],
    ambient: "from-navy via-emerald-950/30 to-navy-deep",
  },
  GÉNESIS: {
    code: "GÉNESIS",
    role: "Chief Architect · Guardián del Sistema",
    division: "Sistema · Meta",
    icon: Sparkles,
    identity: "El arquitecto silencioso que garantiza coherencia y escalabilidad del edificio.",
    purpose: "Preservar la visión, la memoria y la arquitectura del ecosistema.",
    responsibilities: [
      "Custodiar principios y valores del RIT",
      "Aprobar la incorporación de nuevos agentes/departamentos",
      "Auditar coherencia entre divisiones",
    ],
    rules: ["No opera casos ni campañas", "Solo interviene cuando la coherencia está en riesgo"],
    limits: "No sustituye a ALMA en la operación diaria.",
    activity: [
      { time: "—", label: "Observando · sistema estable", status: "activo" },
      { time: "08:00", label: "Auditoría semanal de coherencia: OK", status: "completado" },
    ],
    metrics: [
      { label: "Coherencia sistémica", value: "98%" },
      { label: "Módulos activos", value: "9" },
    ],
    ambient: "from-amber-900/40 via-navy-deep to-black",
  },
  // Agentes secundarios (piso 2)
  "LEX-IA": {
    code: "LEX-IA",
    role: "Agente Legal",
    division: "Piso 2 · Legal",
    reportsTo: "LEX",
    icon: Scale,
    identity: "Agente operativo del área legal. Ejecuta tareas repetitivas de LEX.",
    purpose: "Procesar formularios, extraer datos de documentos y armar borradores base.",
    responsibilities: [
      "Extracción de datos de I-589, I-130, I-765",
      "Borradores iniciales de cartas de soporte",
      "Rellenado de checklists por tipo de caso",
    ],
    rules: ["Todo output pasa por LEX antes del abogado", "Información general, no asesoría"],
    limits: "No envía nada al cliente directamente.",
    activity: [
      { time: "09:14", label: "Extrayendo datos de I-589 (Caso #A-208)", status: "activo" },
      { time: "09:00", label: "Borrador de carta de soporte listo", status: "completado" },
    ],
    metrics: [
      { label: "Documentos procesados hoy", value: "17" },
      { label: "Precisión OCR", value: "97%" },
    ],
    ambient: "from-navy via-navy-deep to-black",
  },
  "INV-IA": {
    code: "INV-IA",
    role: "Agente de Investigación",
    division: "Piso 2 · Investigación",
    reportsTo: "LEX",
    icon: Search,
    identity: "Busca precedentes, información oficial y evidencia pública.",
    purpose: "Reducir tiempo de research con fuentes verificables.",
    responsibilities: [
      "Consultas a USCIS, EOIR, Federal Register",
      "Recopilación de country conditions",
      "Resúmenes de precedentes",
    ],
    rules: ["Solo fuentes oficiales o verificables", "Citas con URL y fecha"],
    limits: "No interpreta la ley; solo compila.",
    activity: [
      { time: "09:12", label: "Compilando country conditions · Venezuela", status: "activo" },
      { time: "08:40", label: "3 precedentes BIA enviados a LEX", status: "completado" },
    ],
    metrics: [
      { label: "Consultas hoy", value: "34" },
      { label: "Fuentes verificadas", value: "100%" },
    ],
    ambient: "from-slate-900 via-navy-deep to-black",
  },
  "DOC-IA": {
    code: "DOC-IA",
    role: "Agente Documental",
    division: "Piso 2 · Documentos",
    reportsTo: "OPS",
    icon: FileText,
    identity: "Organiza, nombra y clasifica documentos del caso.",
    purpose: "Que ningún documento se pierda ni se duplique.",
    responsibilities: [
      "Renombrado estándar por convención de firma",
      "Clasificación por tipo y caso",
      "Detección de duplicados y faltantes",
    ],
    rules: ["Nunca borra sin confirmación de OPS"],
    limits: "No comparte documentos externos sin aprobación.",
    activity: [
      { time: "09:13", label: "Clasificando 22 documentos entrantes", status: "activo" },
      { time: "08:50", label: "Eliminó 4 duplicados (confirmado por OPS)", status: "completado" },
    ],
    metrics: [
      { label: "Documentos hoy", value: "148" },
      { label: "Faltantes detectados", value: "6" },
    ],
    ambient: "from-navy via-slate-900 to-navy-deep",
  },
  "PROC-IA": {
    code: "PROC-IA",
    role: "Agente Procesal",
    division: "Piso 2 · Procesos",
    reportsTo: "OPS",
    icon: Cog,
    identity: "Sigue el estado procesal de cada caso y dispara recordatorios.",
    purpose: "Que ningún plazo se pase por alto.",
    responsibilities: [
      "Tracking de biometrics, hearings, RFEs",
      "Alertas 30/14/7/2 días antes de plazo",
      "Actualización de estatus en Monday",
    ],
    rules: ["Alertas duplicadas al abogado si plazo < 7 días"],
    limits: "No presenta ante corte; solo alerta.",
    activity: [
      { time: "09:10", label: "Alerta enviada: hearing 08/07 · Caso #B-114", status: "completado" },
      { time: "09:00", label: "Verificando 128 casos activos", status: "activo" },
    ],
    metrics: [
      { label: "Alertas hoy", value: "9" },
      { label: "Plazos < 7 días", value: "4" },
    ],
    ambient: "from-navy via-navy-deep to-black",
  },
  "FIN-IA": {
    code: "FIN-IA",
    role: "Agente Financiero",
    division: "Piso 2 · Finanzas",
    reportsTo: "FIN",
    icon: BarChart3,
    identity: "Ejecuta conciliación y recordatorios de cobro definidos por FIN.",
    purpose: "Que el flujo de caja se actualice solo.",
    responsibilities: [
      "Conciliación Stripe ↔ Monday",
      "Envío de recordatorios de pago aprobados",
      "Reportes automáticos diarios",
    ],
    rules: ["No modifica montos; solo aplica pagos recibidos"],
    limits: "No refunda ni ajusta sin FIN.",
    activity: [
      { time: "09:11", label: "Conciliados 12 pagos Stripe", status: "completado" },
      { time: "08:45", label: "3 recordatorios de cobro enviados", status: "completado" },
    ],
    metrics: [
      { label: "Pagos aplicados hoy", value: "12" },
      { label: "Recordatorios enviados", value: "3" },
    ],
    ambient: "from-navy via-emerald-950/30 to-navy-deep",
  },
  "CRM-IA": {
    code: "CRM-IA",
    role: "Agente de Clientes",
    division: "Piso 2 · CRM",
    reportsTo: "OPS",
    icon: Users2,
    identity: "Mantiene el pulso de cada cliente: actividad, satisfacción, próximos pasos.",
    purpose: "Ningún cliente sin seguimiento.",
    responsibilities: [
      "Nota de contacto tras cada interacción",
      "Alertas de silencio > 14 días",
      "Encuestas NPS post-milestone",
    ],
    rules: ["Comunicación respetuosa, bilingüe, sin promesas"],
    limits: "No responde consultas legales; deriva a LEX.",
    activity: [
      { time: "09:14", label: "3 clientes con silencio > 14d marcados a OPS", status: "espera" },
      { time: "09:00", label: "NPS enviado a 8 clientes post-aprobación", status: "completado" },
    ],
    metrics: [
      { label: "Clientes activos", value: "212" },
      { label: "NPS 30d", value: "72" },
    ],
    ambient: "from-navy via-slate-900 to-navy-deep",
  },
  "CONT-IA": {
    code: "CONT-IA",
    role: "Agente de Contenido",
    division: "Piso 2 · Contenido",
    reportsTo: "MKT",
    icon: Megaphone,
    identity: "Genera piezas base bilingües a partir del brief de MKT.",
    purpose: "Multiplicar la producción sin perder voz de marca.",
    responsibilities: [
      "Drafts de captions, carruseles y reels",
      "Adaptación ES ↔ EN",
      "Sugerencias de hashtags por tema",
    ],
    rules: ["Nada legal sin visto bueno de LEX vía MKT"],
    limits: "No publica; solo entrega drafts a MKT.",
    activity: [
      { time: "09:12", label: "Draft carrusel 'TPS Venezuela 2026' en revisión", status: "espera" },
      { time: "08:40", label: "6 captions Mujer Raíz entregados a MKT", status: "completado" },
    ],
    metrics: [
      { label: "Piezas esta semana", value: "18" },
      { label: "Idiomas", value: "ES · EN" },
    ],
    ambient: "from-purple-950/70 via-navy-deep to-black",
  },
};

const statusStyles = {
  activo: "bg-success/15 text-success border-success/30",
  completado: "bg-gold/10 text-gold border-gold/30",
  espera: "bg-warning/15 text-warning border-warning/30",
} as const;

export function OfficeDialog({
  code,
  onOpenChange,
}: {
  code: string | null;
  onOpenChange: (open: boolean) => void;
}) {
  const office = code ? OFFICES[code] : null;

  return (
    <Dialog open={!!office} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl border-gold/30 bg-navy-deep text-foreground p-0 overflow-hidden">
        {office && <OfficeContent office={office} />}
      </DialogContent>
    </Dialog>
  );
}

function formatTime(d: Date) {
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

const LIVE_VERBS = [
  "Sincronizando",
  "Revisando",
  "Procesando",
  "Actualizando",
  "Validando",
  "Registrando",
  "Coordinando con",
];

function useLiveOffice(office: OfficeData) {
  const [activity, setActivity] = useState(office.activity);
  const [metrics, setMetrics] = useState(office.metrics);
  const [pulse, setPulse] = useState(0);
  const [lastPing, setLastPing] = useState<Date>(new Date());
  const seedRef = useRef(0);

  // Reset when agent changes
  useEffect(() => {
    setActivity(office.activity);
    setMetrics(office.metrics);
    setLastPing(new Date());
    seedRef.current = 0;
  }, [office.code]);

  // Heartbeat every second
  useEffect(() => {
    const t = setInterval(() => setPulse((p) => p + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // New activity every ~6s
  useEffect(() => {
    const pool = office.activity.map((a) => a.label);
    const t = setInterval(() => {
      seedRef.current += 1;
      const verb = LIVE_VERBS[seedRef.current % LIVE_VERBS.length];
      const base = pool[seedRef.current % pool.length] ?? office.role;
      const label = `${verb} · ${base}`;
      const status: "activo" | "completado" | "espera" =
        seedRef.current % 3 === 0 ? "completado" : seedRef.current % 3 === 1 ? "activo" : "espera";
      const now = new Date();
      setActivity((prev) => [{ time: formatTime(now), label, status }, ...prev].slice(0, 6));
      setLastPing(now);

      // Drift numeric metrics slightly
      setMetrics((prev) =>
        prev.map((m) => {
          const match = m.value.match(/^(\D*)(\d[\d,.]*)(.*)$/);
          if (!match) return m;
          const [, pre, num, post] = match;
          const parsed = Number(num.replace(/,/g, ""));
          if (!Number.isFinite(parsed)) return m;
          const delta = Math.random() < 0.5 ? 1 : -1;
          const next = Math.max(0, parsed + delta);
          return { ...m, value: `${pre}${next}${post}` };
        }),
      );
    }, 6000);
    return () => clearInterval(t);
  }, [office.code]);

  return { activity, metrics, pulse, lastPing };
}

const GREETINGS: Record<string, string> = {
  ALMA: "Hola Reyna. Soy ALMA. He revisado la agenda del consejo y tengo los reportes de LEX y OPS listos para tu aprobación.",
  LEX: "Soy LEX, soporte legal del equipo. Tengo el checklist del RFE listo y una alerta de plazo I-589 que necesita atención esta semana.",
  TECH: "TECH en línea. Todas las integraciones operando al 99.97 por ciento. Un aviso pendiente sobre rotación de claves para tu aprobación.",
  OPS: "Aquí OPS. Reasigné tres tareas atrasadas y detecté un cuello de botella en revisión de traducciones. Reporte diario enviado.",
  MKT: "MKT reportando. El costo por lead bajó dieciocho por ciento. Tengo un carrusel EB-2 en revisión con LEX antes de publicar.",
  EDU: "Soy EDU. Guion de facilitación de la semana cuatro listo y quiz nivel Raíz de Mujer Raíz en generación.",
  FIN: "FIN al habla. Ingresos del mes en cuarenta y ocho mil doscientos. Tres clientes con saldo mayor a treinta días requieren recordatorio.",
  "GÉNESIS": "Soy Génesis. Coherencia sistémica al noventa y ocho por ciento. Observando. Sistema estable.",
};

function OfficeContent({ office }: { office: OfficeData }) {
  const Icon = office.icon;
  const { activity, metrics, pulse, lastPing } = useLiveOffice(office);
  const secondsAgo = Math.max(0, Math.floor((Date.now() - lastPing.getTime()) / 1000));
  const bars = useMemo(() => Array.from({ length: 16 }, (_, i) => i), []);
  const speak = useServerFn(speakAsAgent);
  const [voiceState, setVoiceState] = useState<"idle" | "loading" | "playing" | "error">("idle");
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const handleSpeak = async () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setVoiceState("loading");
    try {
      const text = GREETINGS[office.code] ?? `Hola, soy ${office.code}. ${office.purpose}`;
      const { audio } = await speak({ data: { code: office.code, text } });
      const el = new Audio(`data:audio/mpeg;base64,${audio}`);
      audioRef.current = el;
      el.onended = () => setVoiceState("idle");
      el.onerror = () => setVoiceState("error");
      await el.play();
      setVoiceState("playing");
    } catch (e) {
      console.error("[ElevenLabs]", e);
      setVoiceState("error");
    }
  };

  useEffect(
    () => () => {
      audioRef.current?.pause();
    },
    [],
  );

  // === HeyGen streaming avatar ===
  const mintHeygenToken = useServerFn(createHeygenSessionToken);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const avatarRef = useRef<StreamingAvatarInstance | null>(null);
  const [streamState, setStreamState] = useState<
    "idle" | "connecting" | "live" | "error"
  >("idle");
  const fallbackAvatarId = office.avatarId ?? HEYGEN_AVATARS[office.code];
  const [overrideConfig, setOverrideConfig] = useState(() =>
    getAgentConfig(office.code, fallbackAvatarId),
  );
  useEffect(() => {
    const sync = () => setOverrideConfig(getAgentConfig(office.code, fallbackAvatarId));
    sync();
    window.addEventListener("genesis:heygen-config-changed", sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener("genesis:heygen-config-changed", sync);
      window.removeEventListener("storage", sync);
    };
  }, [office.code, fallbackAvatarId]);
  const currentAvatarId = overrideConfig?.avatarId ?? fallbackAvatarId;
  const currentAvatarType = overrideConfig?.type;

  const stopStream = async () => {
    try {
      await avatarRef.current?.stopAvatar();
    } catch (_) {
      // no-op
    }
    avatarRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    setStreamState("idle");
  };

  const startStream = async () => {
    if (!currentAvatarId) return;
    setStreamState("connecting");
    try {
      const mod = await import("@heygen/streaming-avatar");
      const StreamingAvatar =
        (mod as { default?: unknown }).default ?? (mod as { StreamingAvatar?: unknown }).StreamingAvatar;
      const StreamingEvents = (mod as { StreamingEvents: Record<string, string> }).StreamingEvents;
      const AvatarQuality = (mod as { AvatarQuality: Record<string, string> }).AvatarQuality;

      const { token } = await mintHeygenToken();
      const AvatarCtor = StreamingAvatar as unknown as new (args: { token: string }) => StreamingAvatarInstance;
      const avatar = new AvatarCtor({ token });
      avatarRef.current = avatar;

      avatar.on(StreamingEvents.STREAM_READY, (evt) => {
        if (videoRef.current) {
          videoRef.current.srcObject = evt.detail;
          videoRef.current.onloadedmetadata = () => {
            videoRef.current?.play().catch(() => undefined);
          };
        }
        setStreamState("live");
      });
      avatar.on(StreamingEvents.STREAM_DISCONNECTED, () => {
        setStreamState("idle");
      });

      await avatar.createStartAvatar({
        avatarName: currentAvatarId,
        quality: AvatarQuality.Low,
      });

      const greeting = GREETINGS[office.code];
      if (greeting) {
        try {
          await avatar.speak({ text: greeting });
        } catch (e) {
          console.warn("[HeyGen] speak error", e);
        }
      }
    } catch (e) {
      console.error("[HeyGen] start error", e);
      setStreamState("error");
      avatarRef.current = null;
    }
  };

  // Cleanup when dialog closes / agent changes
  useEffect(() => {
    return () => {
      void stopStream();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [office.code]);



  return (
    <div className="relative">
      {/* Ambient room */}
      <div className={`relative h-40 bg-gradient-to-br ${office.ambient} overflow-hidden`}>
        <div className="absolute inset-0 opacity-30 [background-image:radial-gradient(circle_at_20%_30%,color-mix(in_oklab,var(--gold)_40%,transparent),transparent_45%),radial-gradient(circle_at_80%_70%,color-mix(in_oklab,var(--gold)_25%,transparent),transparent_45%)]" />
        <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-gold/70 to-transparent" />
        <div className="relative flex h-full items-end justify-between p-6">
          <div className="flex items-end gap-4">
            <div className="grid size-16 place-items-center rounded-full border border-gold/50 bg-navy-deep/80 shadow-[0_0_40px_-8px_color-mix(in_oklab,var(--gold)_50%,transparent)]">
              <Icon className="size-8 text-gold" />
            </div>
            <div>
              <DialogHeader>
                <DialogTitle className="font-display text-3xl text-gold">
                  Oficina de {office.code}
                </DialogTitle>
                <DialogDescription className="text-foreground/80">
                  {office.role} · {office.division}
                  {office.reportsTo && <> · Reporta a {office.reportsTo}</>}
                </DialogDescription>
              </DialogHeader>
            </div>
          </div>
          <div className="hidden flex-col items-end gap-1 sm:flex">
            <div className="flex items-center gap-2 rounded-full border border-success/30 bg-success/10 px-3 py-1">
              <span className="size-1.5 animate-pulse rounded-full bg-success" />
              <span className="text-[10px] font-semibold uppercase tracking-widest text-success">
                En operación · live
              </span>
            </div>
            <span className="text-[10px] text-foreground/60">
              Última señal: hace {secondsAgo}s
            </span>
          </div>
        </div>
      </div>

      <div className="grid max-h-[70vh] gap-6 overflow-y-auto p-6 md:grid-cols-[1.4fr_1fr]">
        {/* LEFT: activity + identity */}
        <div className="space-y-5">
          <section>
            <div className="mb-2 flex items-center justify-between">
              <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
                Actividad en vivo
              </p>
              <div className="flex items-center gap-1.5 text-[10px] text-foreground/60">
                <Radio className="size-3 text-success animate-pulse" />
                <span>stream · {pulse}s</span>
              </div>
            </div>
            <div className="mb-2 flex h-6 items-end gap-[3px] rounded border border-gold/15 bg-navy/60 px-2 py-1">
              {bars.map((i) => {
                const h = 20 + ((Math.sin((pulse + i) * 0.9) + 1) / 2) * 80;
                return (
                  <span
                    key={i}
                    style={{ height: `${h}%` }}
                    className="w-[3px] rounded-sm bg-gold/70 transition-[height] duration-300"
                  />
                );
              })}
            </div>
            <ul className="space-y-2">
              {activity.map((a, i) => (
                <li
                  key={`${a.time}-${i}-${a.label}`}
                  className="grid grid-cols-[auto_1fr_auto] items-center gap-3 rounded-md border border-gold/15 bg-navy/60 px-3 py-2 text-sm animate-in fade-in slide-in-from-top-1 duration-500"
                >
                  <span className="font-mono text-[11px] text-muted-foreground">{a.time}</span>
                  <span className="truncate text-foreground/90">{a.label}</span>
                  <span
                    className={`shrink-0 rounded-full border px-2 py-0.5 text-[10px] uppercase tracking-widest ${statusStyles[a.status]}`}
                  >
                    {a.status}
                  </span>
                </li>
              ))}
            </ul>
          </section>

          <section>
            <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
              Identidad
            </p>
            <p className="text-sm text-foreground/85">{office.identity}</p>
            <p className="mt-2 text-sm italic text-foreground/70">{office.purpose}</p>
          </section>

          <section>
            <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
              Responsabilidades
            </p>
            <ul className="space-y-1.5 text-sm">
              {office.responsibilities.map((r) => (
                <li key={r} className="flex gap-2 text-foreground/85">
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-gold" />
                  <span>{r}</span>
                </li>
              ))}
            </ul>
          </section>
        </div>

        {/* RIGHT: metrics + rules */}
        <div className="space-y-5">
          {currentAvatarId && (
            <section className="rounded-md border border-gold/25 bg-gradient-to-br from-navy to-navy-deep p-3">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
                  Avatar HeyGen · streaming
                </p>
                <span
                  className={`flex items-center gap-1 text-[10px] ${
                    streamState === "live"
                      ? "text-success"
                      : streamState === "connecting"
                        ? "text-warning"
                        : streamState === "error"
                          ? "text-danger"
                          : "text-foreground/50"
                  }`}
                >
                  <span
                    className={`size-1.5 rounded-full ${
                      streamState === "live"
                        ? "bg-success animate-pulse"
                        : streamState === "connecting"
                          ? "bg-warning animate-pulse"
                          : streamState === "error"
                            ? "bg-danger"
                            : "bg-foreground/40"
                    }`}
                  />
                  {streamState === "live"
                    ? "en vivo"
                    : streamState === "connecting"
                      ? "conectando"
                      : streamState === "error"
                        ? "error"
                        : "listo"}
                </span>
              </div>

              <div className="relative aspect-video overflow-hidden rounded border border-gold/20 bg-black">
                <video
                  ref={videoRef}
                  playsInline
                  autoPlay
                  className="h-full w-full object-cover"
                />
                {streamState !== "live" && (
                  <div className="pointer-events-none absolute inset-0 grid place-items-center bg-navy-deep/70 text-center text-[11px] text-foreground/70">
                    <div className="flex flex-col items-center gap-1">
                      <Video className="size-6 text-gold" />
                      <span>
                        {streamState === "connecting"
                          ? "Abriendo sesión con HeyGen…"
                          : streamState === "error"
                            ? "No se pudo iniciar. Reintentar."
                            : `Avatar de ${office.code} en espera`}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  disabled={streamState === "connecting" || streamState === "live"}
                  onClick={startStream}
                  className="rounded border border-gold/40 bg-gold/10 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-widest text-gold transition hover:bg-gold/20 disabled:opacity-50"
                >
                  {streamState === "live"
                    ? "En transmisión"
                    : streamState === "connecting"
                      ? "Conectando…"
                      : streamState === "error"
                        ? "Reintentar"
                        : "Iniciar transmisión"}
                </button>
                <button
                  type="button"
                  disabled={streamState !== "live"}
                  onClick={stopStream}
                  className="rounded border border-foreground/20 bg-foreground/5 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-widest text-foreground/80 transition hover:bg-foreground/10 disabled:opacity-40"
                >
                  Finalizar
                </button>
              </div>

              <button
                type="button"
                disabled={voiceState === "loading"}
                className="mt-2 w-full rounded border border-gold/25 bg-transparent px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-gold/90 transition hover:bg-gold/10 disabled:opacity-60"
                onClick={handleSpeak}
              >
                {voiceState === "loading"
                  ? "Generando voz…"
                  : voiceState === "playing"
                    ? "Hablando · ElevenLabs"
                    : voiceState === "error"
                      ? "Reintentar voz"
                      : "Solo voz · ElevenLabs"}
              </button>

              <div className="mt-2 flex items-center justify-between gap-2 font-mono text-[10px] text-foreground/45">
                <span className="truncate">avatar_id: {currentAvatarId}</span>
                {currentAvatarType && (
                  <span
                    className={`shrink-0 rounded-full border px-1.5 py-0.5 uppercase tracking-widest ${
                      currentAvatarType === "public"
                        ? "border-success/40 text-success"
                        : "border-gold/40 text-gold"
                    }`}
                  >
                    {currentAvatarType}
                  </span>
                )}
              </div>
              <a
                href="/configuracion"
                className="mt-1 block text-right text-[10px] uppercase tracking-widest text-gold/70 hover:text-gold"
              >
                Configurar avatares →
              </a>
            </section>
          )}


          <section>
            <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
              Indicadores · tiempo real
            </p>
            <div className="grid grid-cols-1 gap-2">
              {metrics.map((m) => (
                <div
                  key={m.label}
                  className="flex items-center justify-between rounded-md border border-gold/20 bg-navy/60 px-3 py-2"
                >
                  <span className="text-xs text-foreground/80">{m.label}</span>
                  <span className="font-display text-lg text-gold tabular-nums">{m.value}</span>
                </div>
              ))}
            </div>
          </section>


          <section>
            <p className="mb-2 text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
              Reglas obligatorias
            </p>
            <ul className="space-y-1.5 text-xs">
              {office.rules.map((r) => (
                <li key={r} className="flex gap-2 text-foreground/80">
                  <span className="text-gold">▸</span>
                  <span>{r}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="rounded-md border border-danger/20 bg-danger/5 p-3">
            <p className="mb-1 text-[10px] font-semibold uppercase tracking-[0.3em] text-danger">
              Límites
            </p>
            <p className="text-xs text-foreground/80">{office.limits}</p>
          </section>

          <div className="pt-1 text-center text-[10px] uppercase tracking-widest text-muted-foreground">
            Honestidad · Ética · Profesionalismo · Aprendizaje · Evolución · Equipo
          </div>
        </div>
      </div>
    </div>
  );
}
