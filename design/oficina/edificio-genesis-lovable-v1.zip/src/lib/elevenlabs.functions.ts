import { createServerFn } from "@tanstack/react-start";

// Voces por agente (catálogo de ElevenLabs). Ajustables luego.
const VOICES: Record<string, string> = {
  ALMA: "EXAVITQu4vr4xnSDxMaL", // Sarah — cálida, ejecutiva
  LEX: "Xb7hH8MSUJpSbSDYk0k2", // Alice — clara, profesional
  TECH: "nPczCjzI2devNBz1zQrb", // Brian — técnico, sereno
  OPS: "onwK4e9ZLuTAKqWW03F9", // Daniel — directo
  MKT: "FGY2WhTYpPnrIDTdsKH5", // Laura — expresiva
  EDU: "JBFqnCBsd6RMkjVDRZzb", // George — narrador cálido
  FIN: "cjVigY5qzO86Huf0OWal", // Eric — formal
  "GÉNESIS": "iP95p4xoKVk53GoZ742B", // Chris — sistémico
};

export const speakAsAgent = createServerFn({ method: "POST" })
  .inputValidator((d: { code: string; text: string }) => {
    if (!d?.code || !d?.text) throw new Error("code y text son requeridos");
    if (d.text.length > 800) throw new Error("Texto demasiado largo");
    return d;
  })
  .handler(async ({ data }) => {
    const key = process.env.ELEVENLABS_API_KEY;
    if (!key) throw new Error("ElevenLabs no está conectado");
    const voiceId = VOICES[data.code] ?? VOICES.ALMA;
    const res = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}?output_format=mp3_44100_128`,
      {
        method: "POST",
        headers: {
          "xi-api-key": key,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text: data.text,
          model_id: "eleven_multilingual_v2",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75,
            style: 0.4,
            use_speaker_boost: true,
          },
        }),
      },
    );
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`TTS ${res.status}: ${err}`);
    }
    const buf = await res.arrayBuffer();
    return {
      audio: Buffer.from(buf).toString("base64"),
      voiceId,
    };
  });
