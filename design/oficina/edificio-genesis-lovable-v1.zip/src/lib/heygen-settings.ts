// Persistencia de configuración HeyGen por agente (cliente).
// Guarda avatar_id y tipo público/privado en localStorage para que cada
// agente pueda apuntar a un avatar distinto sin tocar el código.

export type AvatarType = "public" | "private";

export type AgentHeygenConfig = {
  avatarId: string;
  type: AvatarType;
};

const STORAGE_KEY = "genesis.heygen.agents.v1";

function isBrowser() {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

export function loadHeygenConfig(): Record<string, AgentHeygenConfig> {
  if (!isBrowser()) return {};
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, AgentHeygenConfig>;
  } catch {
    return {};
  }
}

export function saveHeygenConfig(cfg: Record<string, AgentHeygenConfig>) {
  if (!isBrowser()) return;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(cfg));
  // Notifica a otras pestañas / componentes escuchando
  window.dispatchEvent(new CustomEvent("genesis:heygen-config-changed"));
}

export function getAgentConfig(
  code: string,
  fallbackAvatarId?: string,
): AgentHeygenConfig | null {
  const all = loadHeygenConfig();
  if (all[code]) return all[code];
  if (fallbackAvatarId) {
    return {
      avatarId: fallbackAvatarId,
      type: fallbackAvatarId.endsWith("_public") ? "public" : "private",
    };
  }
  return null;
}

export function setAgentConfig(code: string, cfg: AgentHeygenConfig) {
  const all = loadHeygenConfig();
  all[code] = cfg;
  saveHeygenConfig(all);
}

export function resetAgentConfig(code: string) {
  const all = loadHeygenConfig();
  delete all[code];
  saveHeygenConfig(all);
}
