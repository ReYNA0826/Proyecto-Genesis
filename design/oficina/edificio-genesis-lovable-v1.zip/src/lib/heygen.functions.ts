import { createServerFn } from "@tanstack/react-start";

/**
 * Mintea un session token de un solo uso para HeyGen Streaming Avatar.
 * El API key nunca sale del servidor.
 */
export const createHeygenSessionToken = createServerFn({ method: "POST" }).handler(
  async () => {
    const key = process.env.HEYGEN_API_KEY;
    if (!key) throw new Error("HEYGEN_API_KEY no configurada");
    const res = await fetch(
      "https://api.heygen.com/v1/streaming.create_token",
      {
        method: "POST",
        headers: { "x-api-key": key, "Content-Type": "application/json" },
      },
    );
    if (!res.ok) {
      const err = await res.text();
      throw new Error(`HeyGen token ${res.status}: ${err}`);
    }
    const json = (await res.json()) as { data?: { token?: string } };
    const token = json?.data?.token;
    if (!token) throw new Error("HeyGen no devolvió token");
    return { token };
  },
);

/**
 * Diagnóstico: indica si el API key está configurado y si el minteo
 * de tokens funciona. Nunca expone el key.
 */
export const getHeygenStatus = createServerFn({ method: "GET" }).handler(async () => {
  const configured = Boolean(process.env.HEYGEN_API_KEY);
  if (!configured) {
    return { configured: false, canMintToken: false, error: "HEYGEN_API_KEY no configurada" };
  }
  try {
    const res = await fetch("https://api.heygen.com/v1/streaming.create_token", {
      method: "POST",
      headers: {
        "x-api-key": process.env.HEYGEN_API_KEY!,
        "Content-Type": "application/json",
      },
    });
    if (!res.ok) {
      const err = await res.text();
      return {
        configured: true,
        canMintToken: false,
        error: `HTTP ${res.status}: ${err.slice(0, 200)}`,
      };
    }
    return { configured: true, canMintToken: true, error: null as string | null };
  } catch (e) {
    return {
      configured: true,
      canMintToken: false,
      error: e instanceof Error ? e.message : String(e),
    };
  }
});
