import { createFileRoute, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { HEYGEN_AVATARS, OFFICES } from "@/components/OfficeDialog";
import { createHeygenSessionToken, getHeygenStatus } from "@/lib/heygen.functions";
import {
  loadHeygenConfig,
  resetAgentConfig,
  setAgentConfig,
  type AgentHeygenConfig,
  type AvatarType,
} from "@/lib/heygen-settings";
import { ArrowLeft, CheckCircle2, XCircle, RotateCcw, Save, Play } from "lucide-react";

export const Route = createFileRoute("/configuracion")({
  head: () => ({
    meta: [
      { title: "Configuración · HeyGen · Proyecto Génesis" },
      {
        name: "description",
        content:
          "Activa la sesión de streaming de HeyGen y ajusta el avatar (público o privado) de cada agente del Reyna Intelligence Team.",
      },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ConfiguracionHeygen,
});

type Status = {
  configured: boolean;
  canMintToken: boolean;
  error: string | null;
};

function ConfiguracionHeygen() {
  const fetchStatus = useServerFn(getHeygenStatus);
  const mintToken = useServerFn(createHeygenSessionToken);

  const [status, setStatus] = useState<Status | null>(null);
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [testing, setTesting] = useState<string | null>(null);
  const [testResult, setTestResult] = useState<{ ok: boolean; msg: string } | null>(null);

  const codes = useMemo(() => Object.keys(HEYGEN_AVATARS), []);
  const [drafts, setDrafts] = useState<Record<string, AgentHeygenConfig>>(() => {
    const stored = loadHeygenConfig();
    const initial: Record<string, AgentHeygenConfig> = {};
    for (const code of Object.keys(HEYGEN_AVATARS)) {
      const fallbackId = HEYGEN_AVATARS[code];
      initial[code] = stored[code] ?? {
        avatarId: fallbackId,
        type: fallbackId.endsWith("_public") ? "public" : "private",
      };
    }
    return initial;
  });
  const [savedFlash, setSavedFlash] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    fetchStatus()
      .then((s) => alive && setStatus(s))
      .catch((e) =>
        alive &&
        setStatus({ configured: false, canMintToken: false, error: String(e?.message ?? e) }),
      )
      .finally(() => alive && setLoadingStatus(false));
    return () => {
      alive = false;
    };
  }, [fetchStatus]);

  const updateDraft = (code: string, patch: Partial<AgentHeygenConfig>) => {
    setDrafts((prev) => ({ ...prev, [code]: { ...prev[code], ...patch } }));
  };

  const handleSave = (code: string) => {
    const cfg = drafts[code];
    setAgentConfig(code, {
      avatarId: cfg.avatarId.trim(),
      type: cfg.type,
    });
    setSavedFlash(code);
    setTimeout(() => setSavedFlash((c) => (c === code ? null : c)), 1600);
  };

  const handleReset = (code: string) => {
    resetAgentConfig(code);
    const fallbackId = HEYGEN_AVATARS[code];
    setDrafts((prev) => ({
      ...prev,
      [code]: {
        avatarId: fallbackId,
        type: fallbackId.endsWith("_public") ? "public" : "private",
      },
    }));
  };

  const handleTestToken = async () => {
    setTesting("__token__");
    setTestResult(null);
    try {
      const { token } = await mintToken();
      setTestResult({
        ok: true,
        msg: `Token OK · ${token.slice(0, 12)}… (válido, 1 uso)`,
      });
    } catch (e) {
      setTestResult({ ok: false, msg: e instanceof Error ? e.message : String(e) });
    } finally {
      setTesting(null);
    }
  };

  return (
    <div className="min-h-screen bg-navy-deep text-foreground">
      <header className="border-b border-gold/20 bg-navy/70 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-foreground/70 hover:text-gold"
          >
            <ArrowLeft className="size-3.5" /> Volver al edificio
          </Link>
          <h1 className="font-display text-lg text-gold sm:text-xl">
            Configuración · HeyGen streaming
          </h1>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-8 px-6 py-8">
        {/* === Estado global === */}
        <section className="rounded-lg border border-gold/25 bg-navy/60 p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
                Estado de la sesión
              </p>
              <h2 className="mt-1 font-display text-xl text-foreground">
                HEYGEN_API_KEY · servidor
              </h2>
              <p className="mt-1 text-xs text-foreground/60">
                El token se mintea del lado del servidor y nunca se expone al navegador.
              </p>
            </div>
            <StatusBadge loading={loadingStatus} status={status} />
          </div>

          {status?.error && (
            <div className="mb-3 rounded border border-danger/30 bg-danger/10 px-3 py-2 text-xs text-danger">
              {status.error}
            </div>
          )}

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleTestToken}
              disabled={testing === "__token__" || !status?.configured}
              className="inline-flex items-center gap-2 rounded border border-gold/40 bg-gold/10 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-widest text-gold hover:bg-gold/20 disabled:opacity-40"
            >
              <Play className="size-3" />
              {testing === "__token__" ? "Probando…" : "Probar minteo de token"}
            </button>
            {testResult && (
              <span
                className={`text-[11px] ${
                  testResult.ok ? "text-success" : "text-danger"
                }`}
              >
                {testResult.msg}
              </span>
            )}
          </div>

          {!status?.configured && !loadingStatus && (
            <p className="mt-4 text-xs text-foreground/70">
              Aún no hay <code className="rounded bg-navy-deep px-1 py-0.5">HEYGEN_API_KEY</code>{" "}
              guardada. Pídele a un administrador que la registre desde el chat de Lovable — se
              guarda encriptada como variable de entorno del servidor.
            </p>
          )}
        </section>

        {/* === Ajustes por agente === */}
        <section>
          <div className="mb-3 flex items-baseline justify-between">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
                Avatares por agente
              </p>
              <h2 className="mt-1 font-display text-xl text-foreground">
                Un avatar por oficina
              </h2>
            </div>
            <p className="text-[10px] uppercase tracking-widest text-foreground/40">
              Guardado local · por navegador
            </p>
          </div>

          <div className="grid gap-3">
            {codes.map((code) => {
              const office = OFFICES[code];
              const draft = drafts[code];
              const fallbackId = HEYGEN_AVATARS[code];
              const dirty =
                draft.avatarId.trim() !== fallbackId ||
                draft.type !== (fallbackId.endsWith("_public") ? "public" : "private");
              return (
                <article
                  key={code}
                  className="rounded-md border border-gold/20 bg-navy/50 p-4"
                >
                  <div className="mb-3 flex items-start justify-between gap-3">
                    <div>
                      <p className="font-display text-lg text-gold">{code}</p>
                      <p className="text-xs text-foreground/70">
                        {office?.role ?? "Agente"}
                        {office?.division ? ` · ${office.division}` : ""}
                      </p>
                    </div>
                    {savedFlash === code && (
                      <span className="text-[10px] uppercase tracking-widest text-success">
                        Guardado ✓
                      </span>
                    )}
                  </div>

                  <div className="grid gap-3 md:grid-cols-[1fr_auto_auto]">
                    <label className="block">
                      <span className="mb-1 block text-[10px] uppercase tracking-widest text-foreground/60">
                        avatar_id (HeyGen)
                      </span>
                      <input
                        type="text"
                        value={draft.avatarId}
                        onChange={(e) => updateDraft(code, { avatarId: e.target.value })}
                        placeholder="ej. Onat_Suit_Sitting_Front_public"
                        className="w-full rounded border border-gold/25 bg-navy-deep px-2 py-1.5 font-mono text-xs text-foreground focus:border-gold/60 focus:outline-none"
                      />
                    </label>

                    <label className="block">
                      <span className="mb-1 block text-[10px] uppercase tracking-widest text-foreground/60">
                        Tipo
                      </span>
                      <select
                        value={draft.type}
                        onChange={(e) =>
                          updateDraft(code, { type: e.target.value as AvatarType })
                        }
                        className="rounded border border-gold/25 bg-navy-deep px-2 py-1.5 text-xs text-foreground focus:border-gold/60 focus:outline-none"
                      >
                        <option value="public">public</option>
                        <option value="private">private</option>
                      </select>
                    </label>

                    <div className="flex items-end gap-2">
                      <button
                        type="button"
                        onClick={() => handleSave(code)}
                        disabled={!dirty}
                        className="inline-flex items-center gap-1 rounded border border-gold/40 bg-gold/10 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-widest text-gold hover:bg-gold/20 disabled:opacity-40"
                      >
                        <Save className="size-3" /> Guardar
                      </button>
                      <button
                        type="button"
                        onClick={() => handleReset(code)}
                        className="inline-flex items-center gap-1 rounded border border-foreground/20 bg-foreground/5 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-widest text-foreground/80 hover:bg-foreground/10"
                        title="Restaurar valor por defecto"
                      >
                        <RotateCcw className="size-3" />
                      </button>
                    </div>
                  </div>

                  <p className="mt-2 text-[10px] text-foreground/40">
                    default:{" "}
                    <span className="font-mono">{fallbackId}</span>{" "}
                    {fallbackId.endsWith("_public") ? "(public)" : "(private)"}
                  </p>
                </article>
              );
            })}
          </div>

          <p className="mt-4 text-[11px] text-foreground/50">
            Los avatares <code>_public</code> funcionan sin plan de streaming. Los privados requieren
            créditos activos en HeyGen (Settings → Subscription).
          </p>
        </section>
      </main>
    </div>
  );
}

function StatusBadge({ loading, status }: { loading: boolean; status: Status | null }) {
  if (loading) {
    return (
      <span className="rounded-full border border-foreground/20 px-3 py-1 text-[10px] uppercase tracking-widest text-foreground/60">
        Verificando…
      </span>
    );
  }
  if (status?.canMintToken) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-success/40 bg-success/10 px-3 py-1 text-[10px] uppercase tracking-widest text-success">
        <CheckCircle2 className="size-3" /> Activa
      </span>
    );
  }
  if (status?.configured) {
    return (
      <span className="inline-flex items-center gap-1 rounded-full border border-warning/40 bg-warning/10 px-3 py-1 text-[10px] uppercase tracking-widest text-warning">
        <XCircle className="size-3" /> Key inválida
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-danger/40 bg-danger/10 px-3 py-1 text-[10px] uppercase tracking-widest text-danger">
      <XCircle className="size-3" /> Sin configurar
    </span>
  );
}
