import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import officesExec from "@/assets/offices-executive.jpg";
import agentsRow from "@/assets/agents-row.jpg";
import councilRoom from "@/assets/council-room.jpg";
import almaAvatar from "@/assets/alma-avatar.jpg";
import reynaAvatar from "@/assets/reyna-avatar.jpg";
import { OfficeDialog } from "@/components/OfficeDialog";
import {
  Home,
  Building2,
  Users2,
  Briefcase,
  Folders,
  FileText,
  MessagesSquare,
  BarChart3,
  Settings,
  Bell,
  Search,
  HelpCircle,
  Mic,
  Rocket,
  Upload,
  CalendarDays,
  Send,
  FileBarChart,
  PieChart,
  MessageCircle,
  Mail,
  BellRing,
  Scale,
  Cpu,
  Cog,
  Megaphone,
  GraduationCap,
  Sparkles,
  Brain,
  Compass,
} from "lucide-react";

export const Route = createFileRoute("/")({
  component: EdificioGenesis,
});

// ————————————————————————————————————————————
// DATA
// ————————————————————————————————————————————

const nav = [
  { icon: Home, label: "Inicio", active: true },
  { icon: Building2, label: "Oficinas Génesis" },
  { icon: Users2, label: "Sala de Conferencias" },
  { icon: Briefcase, label: "Agentes" },
  { icon: Folders, label: "Proyectos" },
  { icon: Users2, label: "Clientes & Casos" },
  { icon: FileText, label: "Documentos" },
  { icon: MessagesSquare, label: "Comunicaciones" },
  { icon: BarChart3, label: "Reportes & Analytics" },
  { icon: Settings, label: "Configuración" },
];

const executives = [
  { code: "ALMA", role: "Directora Ejecutiva", icon: Compass, portrait: true },
  { code: "LEX", role: "Directora Legal", icon: Scale },
  { code: "TECH", role: "Director Tecnológico", icon: Cpu },
  { code: "OPS", role: "Director de Operaciones", icon: Cog },
  { code: "MKT", role: "Directora de Marketing", icon: Megaphone, accent: "violet" as const },
  { code: "EDU", role: "Directora de Educación", icon: GraduationCap },
  { code: "GÉNESIS", role: "Chief Architect · Guardián del Sistema", icon: Sparkles },
];

const agents = [
  { name: "Agente Legal", code: "LEX-IA", icon: Scale },
  { name: "Agente Investigación", code: "INV-IA", icon: Search },
  { name: "Agente Documental", code: "DOC-IA", icon: FileText },
  { name: "Agente Procesal", code: "PROC-IA", icon: Cog },
  { name: "Agente Financiero", code: "FIN-IA", icon: BarChart3 },
  { name: "Agente de Clientes", code: "CRM-IA", icon: Users2 },
  { name: "Agente de Contenido", code: "CONT-IA", icon: Megaphone },
];

const memoria = [
  "Memoria Organizacional",
  "Diario Fundacional",
  "Lecciones de Aprendizaje",
  "Historial de Decisiones",
  "Conocimiento Colectivo",
];

const proyectos = [
  { label: "Proyectos Activos", value: 12 },
  { label: "Tareas en Progreso", value: 23 },
  { label: "Tareas Completadas", value: 128 },
  { label: "Entrega esta Semana", value: 7 },
];

const indicadores = [
  { label: "Casos Activos", value: "128", delta: "+12%", tone: "success" as const },
  { label: "Audiencias Próximas", value: "8", delta: "+5%", tone: "success" as const },
  { label: "Tareas Pendientes", value: "23", delta: "-8%", tone: "danger" as const },
  { label: "Satisfacción Clientes", value: "96%", delta: "+3%", tone: "success" as const },
];

const comunicaciones = [
  { label: "Mensajes No Leídos", value: 5, icon: Mail },
  { label: "Reuniones Hoy", value: 3, icon: CalendarDays },
  { label: "Alertas Importantes", value: 4, icon: BellRing },
  { label: "Recordatorios", value: 7, icon: Bell },
];

const bottomActions = [
  { icon: Rocket, label: "Nuevo Proyecto" },
  { icon: Briefcase, label: "Nuevo Caso" },
  { icon: Upload, label: "Subir Documento" },
  { icon: CalendarDays, label: "Programar Reunión" },
  { icon: Send, label: "Enviar Mensaje" },
  { icon: FileBarChart, label: "Generar Reporte" },
  { icon: PieChart, label: "Ver Indicadores" },
  { icon: Search, label: "Buscar Información" },
  { icon: Mic, label: "Alma IA", primary: true },
];

// ————————————————————————————————————————————
// COMPONENT
// ————————————————————————————————————————————

function EdificioGenesis() {
  const [openOffice, setOpenOffice] = useState<string | null>(null);
  return (
    <div className="min-h-screen text-foreground">
      <div className="mx-auto flex min-h-screen max-w-[1600px]">
        <Sidebar />
        <main className="flex min-w-0 flex-1 flex-col">
          <TopBar />
          <div className="flex-1 space-y-6 px-6 py-6">
            <ExecutiveOfficesRow onOpen={setOpenOffice} />
            <AgentsRow onOpen={setOpenOffice} />
            <CouncilRoomRow />
            <MetricsGrid />
          </div>
          <BottomActionBar />
        </main>
      </div>
      <OfficeDialog code={openOffice} onOpenChange={(o) => !o && setOpenOffice(null)} />
    </div>
  );
}

// ————————————————————————————————————————————
// SIDEBAR
// ————————————————————————————————————————————

function Sidebar() {
  return (
    <aside className="hidden w-72 shrink-0 flex-col border-r border-border/60 bg-sidebar/90 backdrop-blur-md lg:flex">
      <div className="flex items-center gap-3 px-6 pt-6">
        <div className="grid size-10 shrink-0 place-items-center rounded-md border border-gold/40 bg-navy-deep">
          <span className="font-display text-lg text-gold">R</span>
        </div>
        <div className="min-w-0">
          <p className="font-display text-lg leading-none tracking-wide text-gold">RIT</p>
          <p className="mt-1 text-[10px] uppercase tracking-[0.2em] text-muted-foreground">
            Reyna Intelligence Team
          </p>
        </div>
      </div>

      <div className="gold-divider mx-6 mt-6" />

      <div className="flex items-center gap-3 px-6 py-5">
        <img
          src={reynaAvatar}
          alt="Reyna Vázquez"
          className="size-14 shrink-0 rounded-full object-cover ring-2 ring-gold/40 ring-offset-2 ring-offset-sidebar"
        />
        <div className="min-w-0">
          <p className="truncate font-display text-base text-foreground">Reyna Vázquez</p>
          <p className="truncate text-xs text-muted-foreground">Directora Ejecutiva</p>
          <p className="mt-1 flex items-center gap-1.5 text-[10px] uppercase tracking-widest text-success">
            <span className="size-1.5 rounded-full bg-success" /> En línea
          </p>
        </div>
      </div>

      <nav className="mt-2 flex-1 space-y-0.5 px-3">
        <p className="mb-2 px-3 text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
          Navegación
        </p>
        {nav.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              className={`group flex w-full items-center gap-3 rounded-md px-3 py-2 text-left text-sm transition-colors ${
                item.active
                  ? "bg-gold/10 text-gold"
                  : "text-foreground/75 hover:bg-white/5 hover:text-foreground"
              }`}
            >
              <Icon className="size-4 shrink-0" />
              <span className="truncate">{item.label}</span>
              {item.active && <span className="ml-auto h-4 w-0.5 rounded-full bg-gold" />}
            </button>
          );
        })}
      </nav>

      <div className="mx-4 mt-4 mb-4 rounded-lg border border-gold/20 bg-navy/60 p-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <img
              src={almaAvatar}
              alt="Alma"
              className="size-11 rounded-full object-cover ring-1 ring-gold/50"
            />
            <span className="absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-navy-deep bg-success animate-[gold-pulse_2s_ease-in-out_infinite]" />
          </div>
          <div className="min-w-0">
            <p className="text-xs font-medium text-foreground">
              ALMA · <span className="text-muted-foreground">Asistente Ejecutiva</span>
            </p>
            <p className="text-[10px] uppercase tracking-widest text-success">En vivo</p>
          </div>
        </div>
        <div className="mt-3 flex h-8 items-end justify-center gap-0.5">
          {Array.from({ length: 22 }).map((_, i) => (
            <span
              key={i}
              className="w-0.5 rounded-full bg-gold/80"
              style={{
                height: `${20 + Math.abs(Math.sin(i * 1.1)) * 100}%`,
                animation: `voice-bar 1.${(i % 8) + 2}s ease-in-out infinite`,
                animationDelay: `${i * 40}ms`,
              }}
            />
          ))}
        </div>
        <p className="mt-3 text-sm leading-snug text-foreground">Hola, Reyna.</p>
        <p className="text-xs text-muted-foreground">¿En qué puedo ayudarte hoy?</p>
        <button className="mt-3 flex w-full items-center justify-center gap-2 rounded-md border border-gold/30 bg-navy-deep/60 px-3 py-2 text-xs font-medium text-gold transition-colors hover:bg-gold/10">
          <Mic className="size-3.5" /> Hablar con Alma
        </button>
      </div>

      <div className="mx-4 mb-6 border-t border-gold/15 pt-4">
        <p className="text-[10px] uppercase tracking-[0.25em] text-muted-foreground">
          Mensaje del día
        </p>
        <blockquote className="mt-2 border-l-2 border-gold/50 pl-3 font-display text-sm italic text-foreground/85">
          &ldquo;La inteligencia crece cuando el conocimiento permanece y el trabajo se comparte.
          Porque unidos siempre seremos más fuertes.&rdquo;
        </blockquote>
        <p className="mt-2 text-right text-[10px] uppercase tracking-widest text-gold">
          — Lema Fundacional
        </p>
      </div>
    </aside>
  );
}

// ————————————————————————————————————————————
// TOP BAR
// ————————————————————————————————————————————

function TopBar() {
  return (
    <header className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 border-b border-border/60 bg-navy-deep/70 px-6 py-4 backdrop-blur-md sm:flex sm:flex-wrap sm:justify-between">
      <div className="min-w-0">
        <h1 className="font-display text-2xl leading-tight text-foreground sm:text-3xl">
          Edificio Génesis
        </h1>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Tu oficina digital. Un equipo. Una misión.
        </p>
      </div>

      <div className="flex items-center gap-3">
        <div className="hidden items-center gap-2 rounded-md border border-border/70 bg-navy/70 px-3 py-2 md:flex md:w-80">
          <Search className="size-4 text-muted-foreground" />
          <input
            className="w-full bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground"
            placeholder="Buscar en Génesis…"
          />
        </div>

        <button className="relative grid size-10 place-items-center rounded-md border border-border/60 bg-navy/60 text-muted-foreground hover:text-gold">
          <Bell className="size-4" />
          <span className="absolute -right-1 -top-1 grid size-5 place-items-center rounded-full bg-danger text-[10px] font-bold text-white">
            3
          </span>
        </button>
        <button className="grid size-10 place-items-center rounded-md border border-border/60 bg-navy/60 text-muted-foreground hover:text-gold">
          <MessageCircle className="size-4" />
        </button>
        <button className="grid size-10 place-items-center rounded-md border border-border/60 bg-navy/60 text-muted-foreground hover:text-gold">
          <HelpCircle className="size-4" />
        </button>

        <div className="hidden text-right sm:block">
          <p className="font-display text-lg leading-none text-foreground">9:41 AM</p>
          <p className="mt-1 text-[11px] text-muted-foreground">3 de julio de 2026</p>
        </div>
        <div className="hidden items-center gap-1.5 rounded-full border border-success/30 bg-success/10 px-3 py-1 md:flex">
          <span className="size-1.5 animate-pulse rounded-full bg-success" />
          <span className="text-[10px] font-semibold uppercase tracking-widest text-success">
            Génesis en línea
          </span>
        </div>
      </div>
    </header>
  );
}

// ————————————————————————————————————————————
// EXECUTIVE OFFICES (Nivel 3)
// ————————————————————————————————————————————

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4">
      <div className="h-px flex-1 bg-gradient-to-r from-transparent to-gold/40" />
      <span className="font-display text-xs uppercase tracking-[0.35em] text-gold">
        {children}
      </span>
      <div className="h-px flex-1 bg-gradient-to-l from-transparent to-gold/40" />
    </div>
  );
}

function ExecutiveOfficesRow({ onOpen }: { onOpen: (code: string) => void }) {
  return (
    <section className="space-y-3">
      <SectionLabel>Oficinas Ejecutivas</SectionLabel>

      <div className="glass-panel relative overflow-hidden p-2">
        <img
          src={officesExec}
          alt="Edificio Génesis - Nivel de Directores"
          loading="lazy"
          width={1920}
          height={512}
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-40"
        />
        <div className="relative grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7">
          {executives.map((exec) => (
            <ExecutiveCard key={exec.code} exec={exec} onOpen={onOpen} />
          ))}
        </div>
      </div>
    </section>
  );
}

function ExecutiveCard({
  exec,
  onOpen,
}: {
  exec: (typeof executives)[number];
  onOpen: (code: string) => void;
}) {
  const Icon = exec.icon;
  const accentBg =
    exec.accent === "violet"
      ? "from-purple-900/60 to-purple-950/80"
      : "from-navy/70 to-navy-deep/90";

  return (
    <button
      onClick={() => onOpen(exec.code)}
      className="office-frame office-frame-hover group aspect-[3/4] p-3 text-left"
    >
      <div className={`absolute inset-0 bg-gradient-to-b ${accentBg}`} />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold/60 to-transparent" />

      <div className="relative flex h-full flex-col">
        <div className="flex items-start justify-between">
          <div className="min-w-0">
            <p className="font-display text-base leading-tight text-gold sm:text-lg">
              {exec.code}
            </p>
            <p className="mt-0.5 text-[10px] leading-tight text-foreground/80">{exec.role}</p>
          </div>
          <span className="size-1.5 shrink-0 rounded-full bg-success animate-[gold-pulse_2.5s_ease-in-out_infinite]" />
        </div>

        <div className="mt-auto grid place-items-center py-2">
          {exec.portrait ? (
            <img
              src={almaAvatar}
              alt="ALMA"
              className="size-16 rounded-full object-cover ring-2 ring-gold/50 sm:size-20"
            />
          ) : (
            <div className="grid size-14 place-items-center rounded-full border border-gold/40 bg-navy-deep/80 sm:size-16">
              <Icon className="size-6 text-gold" />
            </div>
          )}
        </div>

        <div className="mt-2 flex items-center justify-between text-[9px] uppercase tracking-widest text-muted-foreground">
          <span>Nv 03</span>
          <span className="text-gold/70">Entrar →</span>
        </div>
      </div>
    </button>
  );
}

// ————————————————————————————————————————————
// AGENTS ROW
// ————————————————————————————————————————————

function AgentsRow({ onOpen }: { onOpen: (code: string) => void }) {
  return (
    <section className="space-y-3">
      <SectionLabel>Agentes Principales</SectionLabel>
      <div className="glass-panel relative overflow-hidden p-2">
        <img
          src={agentsRow}
          alt="Agentes de IA de Génesis"
          loading="lazy"
          width={1920}
          height={512}
          className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-30"
        />
        <div className="relative grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7">
          {agents.map((agent) => {
            const Icon = agent.icon;
            return (
              <button
                key={agent.code}
                onClick={() => onOpen(agent.code)}
                className="office-frame office-frame-hover group p-3 text-left"
              >
                <div className="absolute inset-0 bg-gradient-to-b from-navy/60 to-navy-deep/90" />
                <div className="relative flex flex-col gap-2">
                  <div className="flex items-start justify-between">
                    <p className="font-display text-sm leading-tight text-foreground">
                      {agent.name}
                    </p>
                    <span className="size-1.5 rounded-full bg-gold/70" />
                  </div>
                  <p className="text-[10px] font-semibold uppercase tracking-widest text-gold">
                    {agent.code}
                  </p>
                  <div className="mt-2 grid h-14 place-items-center rounded border border-gold/15 bg-navy-deep/70">
                    <Icon className="size-6 text-gold" />
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ————————————————————————————————————————————
// COUNCIL ROOM + LATERAL ROOMS
// ————————————————————————————————————————————

function CouncilRoomRow() {
  return (
    <section className="space-y-3">
      <SectionLabel>Sala de Conferencia · Consejo de Génesis</SectionLabel>
      <div className="grid gap-3 lg:grid-cols-[1fr_2.4fr_1fr]">
        <LateralRoom title="Sala de Estrategia" icon={Compass} />
        <div className="glass-panel relative aspect-[16/8] overflow-hidden">
          <img
            src={councilRoom}
            alt="Sala del Consejo"
            loading="lazy"
            width={1920}
            height={800}
            className="absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-navy-deep/95 via-navy-deep/20 to-navy-deep/40" />
          <div className="absolute inset-0 flex flex-col items-center justify-between p-6">
            <div className="text-center">
              <p className="font-display text-3xl text-gold sm:text-4xl">RIT</p>
              <p className="mt-1 text-[10px] uppercase tracking-[0.4em] text-foreground/80">
                Reyna Intelligence Team
              </p>
              <p className="mt-2 font-display text-xs italic text-gold-soft sm:text-sm">
                El futuro es brillante
              </p>
            </div>
            <div className="flex w-full items-end justify-between">
              <div className="flex -space-x-2">
                {[0, 1, 2, 3].map((i) => (
                  <span
                    key={i}
                    className="size-6 rounded-full border border-gold/40 bg-navy ring-2 ring-navy-deep"
                  />
                ))}
              </div>
              <button className="rounded-md border border-gold/50 bg-gold/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-gold hover:bg-gold/20">
                Convocar Consejo
              </button>
              <div className="flex -space-x-2">
                {[0, 1, 2, 3].map((i) => (
                  <span
                    key={i}
                    className="size-6 rounded-full border border-gold/40 bg-navy ring-2 ring-navy-deep"
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
        <LateralRoom title="Sala de Innovación" icon={Sparkles} />
      </div>
    </section>
  );
}

function LateralRoom({ title, icon: Icon }: { title: string; icon: typeof Compass }) {
  return (
    <div className="glass-panel relative flex aspect-[16/8] flex-col justify-between overflow-hidden p-4 lg:aspect-auto">
      <div className="absolute inset-0 bg-gradient-to-b from-navy/60 to-navy-deep/90" />
      <p className="relative text-[10px] font-semibold uppercase tracking-[0.3em] text-gold">
        {title}
      </p>
      <div className="relative grid flex-1 place-items-center">
        <div className="relative">
          <div className="absolute inset-0 rounded-full bg-gold/20 blur-2xl" />
          <div className="relative grid size-20 place-items-center rounded-full border border-gold/40 bg-navy-deep/80">
            <Icon className="size-8 text-gold" />
          </div>
        </div>
      </div>
    </div>
  );
}

// ————————————————————————————————————————————
// METRICS GRID (bottom)
// ————————————————————————————————————————————

function MetricsGrid() {
  return (
    <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
      <MemoriaCard />
      <ProyectosCard />
      <IndicadoresCard />
      <ComunicacionesCard />
    </section>
  );
}

function CardShell({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="glass-panel p-4">
      <div className="mb-3 text-center">
        <p className="font-display text-sm uppercase tracking-[0.3em] text-gold">{title}</p>
        <div className="gold-divider mt-2" />
      </div>
      {children}
    </div>
  );
}

function MemoriaCard() {
  return (
    <CardShell title="Sala de Memoria">
      <div className="flex items-start gap-4">
        <ul className="min-w-0 flex-1 space-y-2 text-sm">
          {memoria.map((m) => (
            <li key={m} className="flex items-center gap-2 text-foreground/85">
              <span className="size-1.5 shrink-0 rounded-full bg-gold" />
              <span className="truncate">{m}</span>
            </li>
          ))}
        </ul>
        <div className="relative grid size-20 shrink-0 place-items-center">
          <div className="absolute inset-0 rounded-full bg-gold/20 blur-xl" />
          <Brain className="relative size-10 text-gold" />
        </div>
      </div>
    </CardShell>
  );
}

function ProyectosCard() {
  const max = Math.max(...proyectos.map((p) => p.value));
  return (
    <CardShell title="Sala de Proyectos">
      <div className="grid grid-cols-[1fr_auto] gap-4">
        <ul className="min-w-0 space-y-2 text-sm">
          {proyectos.map((p) => (
            <li key={p.label} className="flex items-center justify-between gap-2">
              <span className="flex min-w-0 items-center gap-2 text-foreground/85">
                <span className="size-1.5 shrink-0 rounded-full bg-gold" />
                <span className="truncate">{p.label}</span>
              </span>
              <span className="font-display text-base text-gold">{p.value}</span>
            </li>
          ))}
        </ul>
        <div className="flex items-end gap-1">
          {proyectos.map((p) => (
            <div
              key={p.label}
              className="w-3 rounded-t bg-gradient-to-t from-gold/30 to-gold"
              style={{ height: `${(p.value / max) * 80 + 10}px` }}
            />
          ))}
        </div>
      </div>
    </CardShell>
  );
}

function IndicadoresCard() {
  return (
    <CardShell title="Sala de Indicadores">
      <div className="grid grid-cols-[1fr_auto] items-center gap-4">
        <ul className="min-w-0 space-y-1.5 text-sm">
          {indicadores.map((ind) => (
            <li key={ind.label} className="flex items-center justify-between gap-2">
              <span className="flex min-w-0 items-center gap-2 text-foreground/85">
                <span
                  className={`size-1.5 shrink-0 rounded-full ${
                    ind.tone === "success" ? "bg-success" : "bg-danger"
                  }`}
                />
                <span className="truncate text-xs">{ind.label}</span>
              </span>
              <span className="flex shrink-0 items-baseline gap-1">
                <span className="font-display text-sm text-foreground">{ind.value}</span>
                <span
                  className={`text-[10px] font-semibold ${
                    ind.tone === "success" ? "text-success" : "text-danger"
                  }`}
                >
                  {ind.delta}
                </span>
              </span>
            </li>
          ))}
        </ul>
        <RadialMeta value={96} target={95} />
      </div>
    </CardShell>
  );
}

function RadialMeta({ value, target }: { value: number; target: number }) {
  const r = 32;
  const c = 2 * Math.PI * r;
  const offset = c - (value / 100) * c;
  return (
    <div className="relative grid size-24 shrink-0 place-items-center">
      <svg className="absolute inset-0 -rotate-90" viewBox="0 0 80 80">
        <circle cx="40" cy="40" r={r} fill="none" stroke="oklch(0.3 0.03 260)" strokeWidth="6" />
        <circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          stroke="url(#goldGrad)"
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
        />
        <defs>
          <linearGradient id="goldGrad" x1="0" x2="1" y1="0" y2="1">
            <stop offset="0" stopColor="oklch(0.85 0.09 82)" />
            <stop offset="1" stopColor="oklch(0.7 0.14 82)" />
          </linearGradient>
        </defs>
      </svg>
      <div className="relative text-center">
        <p className="font-display text-lg text-gold">{value}%</p>
        <p className="text-[9px] uppercase tracking-widest text-muted-foreground">Meta {target}%</p>
      </div>
    </div>
  );
}

function ComunicacionesCard() {
  return (
    <CardShell title="Centro de Comunicaciones">
      <ul className="space-y-2 text-sm">
        {comunicaciones.map((c) => {
          const Icon = c.icon;
          return (
            <li
              key={c.label}
              className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3"
            >
              <span className="grid size-8 shrink-0 place-items-center rounded-md border border-gold/20 bg-navy-deep/70">
                <Icon className="size-4 text-gold" />
              </span>
              <span className="truncate text-foreground/85">{c.label}</span>
              <span className="font-display text-base text-gold">{c.value}</span>
            </li>
          );
        })}
      </ul>
    </CardShell>
  );
}

// ————————————————————————————————————————————
// BOTTOM ACTION BAR
// ————————————————————————————————————————————

function BottomActionBar() {
  return (
    <footer className="border-t border-border/60 bg-navy-deep/80 px-4 py-3 backdrop-blur-md">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4">
        <div className="flex min-w-0 flex-wrap items-center gap-2">
          {bottomActions.map((a) => {
            const Icon = a.icon;
            return (
              <button
                key={a.label}
                className={`group flex shrink-0 items-center gap-2 rounded-md border px-3 py-2 text-xs font-medium transition-colors ${
                  a.primary
                    ? "border-gold/60 bg-gold/15 text-gold hover:bg-gold/25"
                    : "border-transparent text-muted-foreground hover:border-gold/20 hover:bg-navy/60 hover:text-gold"
                }`}
              >
                <Icon className="size-4" />
                <span className="hidden sm:inline">{a.label}</span>
              </button>
            );
          })}
        </div>
        <div className="hidden shrink-0 items-center gap-3 rounded-md border border-gold/40 bg-gold/10 px-4 py-2 md:flex">
          <Sparkles className="size-4 text-gold" />
          <div className="text-right">
            <p className="font-display text-sm text-gold">El futuro es brillante.</p>
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground">
              — Lema de Visión
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
